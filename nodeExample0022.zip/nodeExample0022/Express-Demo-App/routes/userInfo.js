var express = require('express');
var router = express.Router(); 
var mongoClient = require('mongoose'); 



//RESTful Operations with MongoDB Database  

/* 

// The following MongoDB Commands need to be run with default user. 
(For Testing purpose only) 

db; 

show dbs; 

use mydb01; 

show collections; 

db.users.find().pretty(); 

db.users.remove({_id:ObjectId("5e72f04aed124e0d04d6eceb")}); 

db.users.insert({ userId : 102,  name : "A2",  email : "a2@g1.com",  dob : ISODate("2002-02-02")}); 

*/  


var mongoPort = '27017'; 
var mongoDataBase = "mydb01";
var mongoModelname = "user"; 
var mongoSchema = mongoClient.Schema; 

var connectionString = "mongodb://localhost:" + mongoPort + "/" + mongoDataBase; 


// Create a MOngoDB connection 
mongoClient.connect(connectionString); 

var userSchema = new mongoSchema( 
{ 
    userId : Number, 
    name : String,  
    email : String, 
    dob : Date 
}); 

var mongoUserData = mongoClient.model(mongoModelname, userSchema); 





router.post('/', function(request, response, next) 
{
    var a = parseInt(request.body.a); 
    var b = request.body.b; 
    var c = request.body.c; 
    var d = request.body.d; 
    var action = request.body.action; 
    
    
    if(action == "Show") /* GET All User Data. */ 
    {
        mongoUserData.find(function(err,allUsers) 
        {
            if(err)
                return response.send(err); 
            
            response.json(allUsers); 
        }); 
    } 
    else if(action == "Fetch") /* GET Specific User Data. */ 
    {
        mongoUserData.findOne({userId:a},function(err,partUser) 
        {
            if(err)
                return response.send(err); 
            
            response.json(partUser); 
        }); 
    } 
    else if(action == "Delete") /* DELETE User By User Id. */ 
    {
        mongoUserData.remove({userId:a},function(err) 
        {
            if(err)
                return response.send(err); 
            
            mongoUserData.find(function(err,othUsers) 
            {
                if(err)
                    return response.send(err); 
                
                response.json(othUsers); 
            }); 
        }); 
    } 
    else if(action == "Update") /* UPDATE User By User Id. */ 
    {
        mongoUserData.findOne({userId:a},function(err,updUser) 
        {
            if(err)
                return response.send(err); 
            
            for (prop in request.body) 
            {
                updUser[prop] = request.body[prop]; 
            } 

            updUser.save(function(err1,result) 
            { 
                mongoUserData.find(function(err2,updUser1) 
                { 
                    if(err) 
                        return response.send(err); 
                    
                    response.json(updUser1); 
                }); 
            }); 
        }); 
    } 
    else if(action == "Add") /* ADD user by User Id. */ 
    {
        var user_body = new mongoUserData(request.body); 

        user_body.save(function(err) 
        {
            if(err) 
                return response.send(err); 

            mongoUserData.find(function(err,updUser) 
            {
                if(err) 
                    return response.send(err); 
                
                response.json(updUser); 
            }); 
        }); 
        
        /* var addUser; 
        
        for (prop in request.body) 
        { 
            addUser[prop] = request.body[prop]; 
        } 
        
        addUser.save(function(err1) 
        { 
            if(err1) 
                return response.send(err1); 

            mongoUserData.find(function(err2,updAddUser) 
            { 
                if(err2) 
                    return response.send(err2); 
                
                response.json(updAddUser); 
            }); 
        });  */

    } 
}); 



module.exports = router;